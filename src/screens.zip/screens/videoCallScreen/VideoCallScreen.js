import React from 'react'
import './videoCall.css'
import CallEndIcon from '@mui/icons-material/CallEnd';
import { Mic, MicOff, Videocam, VideocamOff } from '@mui/icons-material';
import { IconButton } from '@mui/material'

export default function VideoCallScreen() {
  return (
    <div className='video_call_main text-white'>
        <div className='video_call_header'>
            <p className='text-muted'>01:10</p>
        </div>

        <div className='video_call_div'>

        </div>

        <div className='container video_call_footer'>
            <div className='container video_call_footer_icons'>
                <div className='container icon_1'>
                    <IconButton >
                        <Mic/>
                    </IconButton>
                </div>
                <div className='container icon_2'>
                    <IconButton>
                        <Videocam/>
                    </IconButton>
                </div>
                <div className='container icon_3'>
                    <IconButton>
                        <CallEndIcon/>
                    </IconButton>
                </div>
                
            </div>
        </div>
    </div>
  )
}
