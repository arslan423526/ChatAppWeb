import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Sidebar from './sidebar/Sidebar'
import Chat from './chat/Chat'
import Grid from '@mui/material/Grid';

export default function Home({ children }) {
  return (
    <div style={{}}>
      <div className='app_body'>
        <Sidebar/>
        <Chat/>
      {/* <Grid container>
        <Grid item md={4}>
          <Sidebar />
        </Grid>    
        <Grid item md={8}>
          {children}
        </Grid>     
      </Grid> */}
      </div>
    </div>
  )
}
