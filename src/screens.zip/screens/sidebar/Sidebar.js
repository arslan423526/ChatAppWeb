import { Chat, MoreVert, SearchOutlined, Unsubscribe } from '@mui/icons-material'
import { Avatar, IconButton } from '@mui/material'
import React, {useEffect, useState} from 'react'
import db from '../../components/firebase'
import './sidebar.css'
import SidebarChat from './SidebarChat'
import { collection, getDocs } from "firebase/firestore";
// import { getCities } from '../../components/firebase'

function Sidebar() {
    const [rooms, setRooms] = useState([])

    async function getCities(db) {
        const citiesCol = collection(db, 'rooms');
        const citySnapshot = await getDocs(citiesCol);
        setRooms(
            citySnapshot.docs.map(doc => ({
                id: doc.id,
                data: doc.data(),
            }))
        )
     }

     
    useEffect(() => {
        
        getCities(db);
        
        return () => {
            getCities();
        }
             
    }, []);

    return (
        <div className='sidebar'>
            <div className="sidebar_header">
                <Avatar />
                <div className='sidebar_header_right'>
                    <IconButton>
                        <Chat />
                    </IconButton>
                    <IconButton>
                        <MoreVert />
                    </IconButton>
                
                </div>
            </div>

            <div className='sidebar_search'>
                <div className='sidebar_search_field'>
                    <SearchOutlined />
                    <input placeholder='Search for chats' type="text"/>
                </div>
            </div>

            <div className='sidebar_chats'>
                <SidebarChat /> 
                <SidebarChat /> 
                <SidebarChat /> 
                <SidebarChat /> 
                
                {/* {rooms.map(room => (
                    <SidebarChat key={room.id} id={room.id} name={room.data.name} />
                ))} */}

            </div>
        </div>
    )
}

export default Sidebar
