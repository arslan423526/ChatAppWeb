import { Avatar } from '@mui/material'
import React, { useEffect, useState} from 'react'
import { Link } from 'react-router-dom';

function SidebarChat({id, name}) {

    const [seed, setSeed] = useState("");
    useEffect(() => {
        setSeed(Math.floor(Math.random() * 5000));
    }, [])

    return (
        // <Link to={`/rooms/${id}`}>
        <div className='sidebarChat'>
            
                <Avatar src={`https://avatars.dicebear.com/api/male/${seed}.svg`}/>
                <div className='sidebarChat_info'>
                    <h2>Name</h2>
                    <p>Last message...</p>
                </div>
            
        </div>
        // </Link>
    )
}

export default SidebarChat
