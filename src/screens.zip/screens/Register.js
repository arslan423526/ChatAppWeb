import React from 'react'
import { AuthForm } from './Login'
import { Link } from "react-router-dom";

export default function Register() {
    return (
        <div className="loginContainer">
          <div className="inner">
              <div className="logo">Messenger</div>
              <div className="title">Sign up</div>

              <AuthForm />

              <div className="switchOption">
                Dont have an accout yet? <Link to="/login">Sign in</Link>
              </div>
            </div>
        </div>
    )
}
