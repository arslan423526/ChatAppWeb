import { AttachFile, Camera, CameraAltOutlined, FileCopyOutlined, InsertEmoticon, LocationCityOutlined, LocationDisabled, MapRounded, MapsHomeWorkOutlined, MicOutlined, MonitorHeart, MoreVert, PermCameraMic, SearchOutlined, Videocam } from '@mui/icons-material'
import { Avatar, IconButton } from '@mui/material'
import React, {useState, useEffect} from 'react'
import './chat.css'
import '../../style.scss'
import { useParams } from 'react-router-dom'
import db from '../../components/firebase'
import { collection, getDocs } from "firebase/firestore";

function Chat() {
    // const [input, setInput] = useState("")
    // const { roomId } = useParams();
    // const [roomName, setRoomName] = useState("")

    // async function getRoomName(db) {
    //     console.log("i am entered")
    //     const citiesCol = collection(db, 'rooms');
    //     const citySnapshot = await getDocs(citiesCol);


    //  }

    // useEffect(() => {
    //     if(roomId){
    //         getRoomName(db)
    //     }
    // }, [roomId])

    // const sendMessage = (e) => {
    //     e.preventDefault();
    //     console.log("You typed: ", input);
    //     setInput("");
    // }

    return (
        <div className='chat'>
            <div className='chat_header'>
                <Avatar/>
                <div className='chat_header_info'>
                    <h3>Name</h3>
                    <p>Last seen at ... </p>
                </div>
                <div className='chat_header_right'>
                    <IconButton>
                        <SearchOutlined/>
                    </IconButton>
                    <IconButton>
                        <MoreVert />
                    </IconButton>
                </div>
            </div>
            <div className='chat_body'>
                <div className='chat_bubble_sender'>
                    <Avatar/>
                    {/* <div className="time">2:16 AM</div> */}
                    <div className='chat_message_sender'>
                        <p>Hey there?</p>
                    </div>
                </div>
                <div className='chat_bubble_sender'>
                    <Avatar/>
                    {/* <div className="time">2:16 AM</div> */}
                    <div className='chat_message_sender'>
                        <p>How are you? Hope you are all good. 😊</p>
                    </div>
                </div>

                {/* <div className='chat_bubble_reciever'>
                    <Avatar/>
                    <div className='chat_message_reciever'>
                        <p>Hey there?</p>
                    </div>
                </div> */}

                <div className='chat_bubble_reciever'>
                    {/* <div className="time">2:16 AM</div> */}
                    <div className='chat_message_reciever'>
                        <p>Hii Jake</p>
                    </div>
                    <Avatar/>
                </div>

                <div className='chat_bubble_reciever'>
                    {/* <div className="time">2:16 AM</div> */}
                    <div className='chat_message_reciever'>
                        <p>Sorry i was lil busy at that moment.</p>
                    </div>
                    <Avatar/>
                </div>

                <div className='chat_bubble_reciever'>
                    
                    {/* <div className="time">2:16 AM</div> */}
                    <div className='chat_message_reciever'>
                        <p>Hi how are you? i hope you are okay, Hi how are you? i hope you are okay,, Hi how are you? i hope you are okay Hi how are you? i hope you are okay</p>
                    </div>
                    <Avatar/>
                </div>

            </div>
            <div className='chat_footer'>
                <form className='chat_footer_message_form'>
                    <input
                        className="input-field"
                        // value={input}
                        // onChange={e => {
                        //     setInput(e.target.value)
                        // }}
                        placeholder="Send a message" type="text" 
                    />
                    <button type='submit' >Send</button>
                    <MicOutlined/>
                </form>
                <div className='chat_extension'>
                <AttachFile/>
                <CameraAltOutlined/>
                <FileCopyOutlined/>
                <Videocam/>
                <LocationDisabled/>
                <div className='chat_extension_bar'>
                </div>
                <div className='chat_extension_bar_right'>
                    <IconButton>
                        <InsertEmoticon/>
                    </IconButton>
                    <IconButton className='heart_emoji'>
                        <h5>❤️</h5>
                    </IconButton>
                </div>
            </div>
            </div>

        </div>
    )
}

export default Chat
