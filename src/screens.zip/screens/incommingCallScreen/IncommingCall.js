import React from 'react';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import './incommingCall.css'

const IncomingCall = () => {

    // const styles = {
    //     name: {
    //       fontSize: 30,
    //       fontWeight: 'bold',
    //       color: 'white',
    //       marginTop: 100,
    //       marginBottom: 15,
    //     },
    //     phoneNumber: {
    //       fontSize: 20,
    //       color: 'white',
    //     },
    //     bg: {
    //       backgroundColor: 'red',
    //       flex: 1,
    //       alignItems: 'center',
    //       padding: 10,
    //       paddingBottom: 50,
    //     },
      
    //     row: {
    //       width: '100%',
    //       flexDirection: 'row',
    //       justifyContent: 'space-around',
    //     },
    //     iconContainer: {
    //       alignItems: 'center',
    //       marginVertical: 20,
    //     },
    //     iconText: {
    //       color: 'white',
    //       marginTop: 10,
    //     },
    //     iconButtonContainer: {
    //       backgroundColor: 'red',
    //       padding: 15,
    //       borderRadius: 50,
    //       margin: 10,
    //     },
    //   };

  return (
    <div className='incomming_call_bg text-white'>
        <div className='incomming_call_header'>
            <h6 style={{fontWeight: 'bold', fontSize: 28}}>Hamza Asif</h6>
            <p>Video Calling...</p>
        </div>


      <div className='incomming_call_btns'>
        {/* Decline Button */}
          <div className='decline_btn'>
            <CancelIcon/>
            <p className=''>Decline</p>
          </div>
          

        {/* Accept Button */}
          <div className='accept_btn'>
            <CheckCircleIcon/>
            <p className=''>Accept</p>
          </div>
          
      </div>
    </div>
  );
};


export default IncomingCall;
